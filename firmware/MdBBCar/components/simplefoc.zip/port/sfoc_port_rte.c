#include "rtthread.h"
#include "sfoc_port.h"

void *sfoc_port_malloc(uint32_t size)
{
    return rt_malloc(size);
}

void sfoc_port_delayms(uint32_t ms)
{
    rt_thread_mdelay(ms);
}

extern uint32_t board_get_cur_us(void);

uint32_t sfoc_port_micros(void)
{
    return board_get_cur_us();
}
