#ifndef __SFOC_PORT_H__
#define __SFOC_PORT_H__

#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif

void *sfoc_port_malloc(uint32_t size);
void  sfoc_port_delayms(uint32_t ms);
uint32_t sfoc_port_micros(void);


void sfoc_port_sincos(float a, float* s, float* c);
float sfoc_port_sqrtApprox(float number);
float sfoc_port_normalize_angle(float angle);

#define SIMPLEFOC_DEBUG(...)

#ifdef __cplusplus
}
#endif
#endif
