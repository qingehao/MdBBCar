#ifndef __SFOC_BLDC_MOTOR_H__
#define __SFOC_BLDC_MOTOR_H__
#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "sfoc_motor.h"
#include "sfoc_foc_driver.h"

typedef struct
{
    sfoc_motor_t        foc;
    sfoc_driver_t      *driver;
    float Ua, Ub, Uc;//!< Current phase voltages Ua,Ub and Uc set to motor
    long open_loop_timestamp;
} sfoc_bldc_motor_t;


void sfoc_bldc_motor_init(sfoc_bldc_motor_t *bldc, int pp, float _R, float _KV, float _inductance);
float sfoc_bldc_motor_angle_openloop(sfoc_bldc_motor_t *motor, float target_angle);
float sfoc_bldc_motor_velocity_openloop(sfoc_bldc_motor_t *motor, float target_velocity);

#ifdef __cplusplus
}
#endif
#endif
