#ifndef __SFOC_H__
#define __SFOC_H__
#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "sfoc_utils.h"
#include "sfoc_bldc_motor.h"
#include "sfoc_driver_md_port.h"

#ifdef __cplusplus
}
#endif
#endif
