#include "sfoc_foc_driver.h"
#include "bsp_pwm.h"
#include "sfoc_driver_md_port.h"
#include "sfoc_utils.h"

static void _set_pwm(void *arg, float Ua, float Ub, float Uc)
{
    sfoc_md_bsp_driver_t *md_driver = (sfoc_md_bsp_driver_t *)arg;
    sfoc_driver_t *driver = &md_driver->driver;

    // limit the voltage in driver
    Ua = _constrain(Ua, 0.0f, driver->voltage_limit);
    Ub = _constrain(Ub, 0.0f, driver->voltage_limit);
    Uc = _constrain(Uc, 0.0f, driver->voltage_limit);
    // calculate duty cycle
    // limited in [0,1]
    driver->dc_a = _constrain(Ua / driver->voltage_power_supply, 0.0f , 1.0f );
    driver->dc_b = _constrain(Ub / driver->voltage_power_supply, 0.0f , 1.0f );
    driver->dc_c = _constrain(Uc / driver->voltage_power_supply, 0.0f , 1.0f );

    // hardware specific writing
    // hardware specific function - depending on driver and mcu
    bsp_pwm_set_duty(md_driver->pwm_dev, md_driver->a_ch, driver->dc_a);
    bsp_pwm_set_duty(md_driver->pwm_dev, md_driver->b_ch, driver->dc_b);
    bsp_pwm_set_duty(md_driver->pwm_dev, md_driver->c_ch, driver->dc_c);
}

static void _set_phase_state(void *arg, SFOC_PHASE_STATE sa, SFOC_PHASE_STATE sb, SFOC_PHASE_STATE sc)
{

}

static void _enable(void *arg)
{

}

static void _disable(void *arg)
{

}

void sfoc_driver_md_port_init(sfoc_md_bsp_driver_t *driver, uint8_t index, uint8_t pha_ch, uint8_t phb_ch, uint8_t phc_ch)
{
    driver->pwm_dev = bsp_pwm_request(index);

    if (driver->pwm_dev)
    {
        driver->driver.set_pwm = _set_pwm;
        driver->driver.set_phase_state = _set_phase_state;
        driver->driver.enable = _enable;
        driver->driver.disable = _disable;

        driver->a_ch = pha_ch;
        driver->b_ch = phb_ch;
        driver->c_ch = phc_ch;

        bsp_pwm_enable(driver->pwm_dev, pha_ch, 1);
        bsp_pwm_enable(driver->pwm_dev, phb_ch, 1);
        bsp_pwm_enable(driver->pwm_dev, phc_ch, 1);

        driver->driver.arg = driver;

        driver->driver.initialized = 1;
        driver->driver.voltage_limit = driver->driver.voltage_power_supply;
    }
}
