#ifndef __SFOC_BLDC_DRVER_H__
#define __SFOC_BLDC_DRVER_H__
#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif
#include "sfoc_foc_driver.h"
#include "bsp_pwm.h"

typedef struct
{
    sfoc_driver_t driver;
    bsp_pwm_dev_t *pwm_dev;
    uint8_t a_ch;
    uint8_t b_ch;
    uint8_t c_ch;
} sfoc_md_bsp_driver_t;

void sfoc_driver_md_port_init(sfoc_md_bsp_driver_t *driver, uint8_t index, uint8_t pha_ch, uint8_t phb_ch, uint8_t phc_ch);


#ifdef __cplusplus
}
#endif
#endif

