#ifndef __SFOC_SENSOR_H__
#define __SFOC_SENSOR_H__

#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    SFOC_DIRECTION_CW      = 1,  // clockwise
    SFOC_DIRECTION_CCW     = -1, // counter clockwise
    SFOC_DIRECTION_UNKNOWN = 0   // not yet known or invalid state
} SFOC_DIRECTION;

typedef float (*sfoc_get_sensor_angle_t)(void *user_data);

typedef struct
{
    sfoc_get_sensor_angle_t getSensorAngle;
    void   *user_data;
    float   min_elapsed_time;           // default is 100 microseconds, or 10kHz
    float   velocity;                   // velocity calculation variables
    float   angle_prev;                 // result of last call to getSensorAngle(), used for full rotations and velocity
    long    angle_prev_ts;              // timestamp of last call to getAngle, used for velocity
    float   vel_angle_prev;             // angle at last call to getVelocity, used for velocity
    long    vel_angle_prev_ts;          // last velocity calculation timestamp
    int32_t full_rotations;             // full rotation tracking
    int32_t vel_full_rotations;         // previous full rotation value for velocity calculation
} sfoc_sensor_t;

/**
 * @brief Updates the sensor values by reading the hardware sensor.
 *
 * @param sensor
 */
void sfoc_sensor_update(sfoc_sensor_t *sensor);

/**
 * @brief Get current angular velocity (rad/s)
 *
 * @param sensor
 * @return float velocity (rad/s)
 */
float sfoc_sensor_getVelocity(sfoc_sensor_t *sensor);

/**
 * @brief Get mechanical shaft angle in the range 0 to 2PI.
 *
 * @param sensor
 * @return float
 */
float sfoc_sensor_getMechanicalAngle(sfoc_sensor_t *sensor);

/**
 * @brief Get current position (in rad) including full rotations and shaft angle.
 *
 * @param sensor
 * @return float
 */
float sfoc_sensor_getAngle(sfoc_sensor_t *sensor);

/**
 * @brief On architectures supporting it, this will return a double precision position value
 *
 * @param sensor
 * @return double
 */
double sfoc_sensor_getPreciseAngle(sfoc_sensor_t *sensor);

/**
 * @brief
 *
 * @param sensor
 * @return int32_t
 */
int32_t sfoc_sensor_getFullRotations(sfoc_sensor_t *sensor);

/**
 * @brief Get the number of full rotations
 *
 * @param sensor
 * @return int
 */
int sfoc_sensor_needsSearch(sfoc_sensor_t *sensor);

/**
 * @brief
 *
 * @param sensor
 * @param sensor_angle
 * @param user_data
 * @return int32_t
 */
int32_t sfoc_sensor_init(sfoc_sensor_t *sensor, sfoc_get_sensor_angle_t sensor_angle, void *user_data);

/**
 * @brief Set min_elapsed_time
 *
 * @param sensor
 * @param time
 */
void sfoc_sensor_set_min_elapsed_time(sfoc_sensor_t *sensor, float time);

#ifdef __cplusplus
}
#endif
#endif
