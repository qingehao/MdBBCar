#ifndef __SFOC_MOTOR_H__
#define __SFOC_MOTOR_H__

#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif
#include "sfoc_sensor.h"
#include "sfoc_current_sense.h"
#include "sfoc_pid.h"
#include "sfoc_lpf.h"

/**
 *  Motiron control type
 */
typedef enum
{
  torque            = 0x00,     //!< Torque control
  velocity          = 0x01,     //!< Velocity motion control
  angle             = 0x02,     //!< Position/angle motion control
  velocity_openloop = 0x03,
  angle_openloop    = 0x04
} SFOC_MOTION_CONTROL_TYPE;

/**
 *  Motiron control type
 */
typedef enum
{
    voltage            = 0x00,     //!< Torque control using voltage
    dc_current         = 0x01,     //!< Torque control using DC current (one current magnitude)
    foc_current        = 0x02,     //!< torque control using dq currents
} SFOC_TORQUE_CONTROL_TYPE;

/**
 *  FOC modulation type
 */
typedef enum
{
    SinePWM            = 0x00,     //!< Sinusoidal PWM modulation
    SpaceVectorPWM     = 0x01,     //!< Space vector modulation method
    Trapezoid_120      = 0x02,
    Trapezoid_150      = 0x03,
} SFOC_MODULATION_TYPE;

typedef enum
{
  motor_uninitialized = 0x00,     //!< Motor is not yet initialized
  motor_initializing  = 0x01,     //!< Motor intiialization is in progress
  motor_uncalibrated  = 0x02,     //!< Motor is initialized, but not calibrated (open loop possible)
  motor_calibrating   = 0x03,     //!< Motor calibration in progress
  motor_ready         = 0x04,     //!< Motor is initialized and calibrated (closed loop possible)
  motor_error         = 0x08,     //!< Motor is in error state (recoverable, e.g. overcurrent protection active)
  motor_calib_failed  = 0x0E,     //!< Motor calibration failed (possibly recoverable)
  motor_init_failed   = 0x0F,     //!< Motor initialization failed (not recoverable)
} SFOC_MOTOR_STATUS;

typedef struct
{
    // state variables
    float   target; //!< current target value - depends of the controller
    float   feed_forward_velocity; //!< current feed forward velocity
  	float   shaft_angle;//!< current motor angle
  	float   electrical_angle;//!< current electrical angle
  	float   shaft_velocity;//!< current motor velocity
    float   current_sp;//!< target current ( q current )
    float   shaft_velocity_sp;//!< current target velocity
    float   shaft_angle_sp;//!< current target angle
    sfoc_dq_voltage_t voltage;//!< current d and q voltage set to the motor
    sfoc_dq_current_t current;//!< current d and q current measured
    float   voltage_bemf; //!< estimated backemf voltage (if provided KV constant)
    float   Ualpha, Ubeta; //!< Phase voltages U alpha and U beta used for inverse Park and Clarke transform

    // motor configuration parameters
    float voltage_sensor_align;//!< sensor and motor align voltage parameter
    float velocity_index_search;//!< target velocity for index search

    // motor physical parameters
    float	phase_resistance; //!< motor phase resistance
    int pole_pairs;//!< motor pole pairs number
    float KV_rating; //!< motor KV rating
    float	phase_inductance; //!< motor phase inductance

    // limiting variables
    float voltage_limit; //!< Voltage limiting variable - global limit
    float current_limit; //!< Current limiting variable - global limit
    float velocity_limit; //!< Velocity limiting variable - global limit

    // motor status vairables
    int8_t enabled;//!< enabled or disabled motor flag
    SFOC_MOTOR_STATUS motor_status; //!< motor status

    // pwm modulation related variables
    SFOC_MODULATION_TYPE foc_modulation;//!<  parameter determining modulation algorithm
    int8_t modulation_centered;//!< flag (1) centered modulation around driver limit /2  or  (0) pulled to 0


    // configuration structures
    SFOC_TORQUE_CONTROL_TYPE torque_controller; //!< parameter determining the torque control type
    SFOC_MOTION_CONTROL_TYPE controller; //!< parameter determining the control loop to be used

    // controllers and low pass filters
    sfoc_pid_t PID_current_q; //!< parameter determining the q current PID config
    sfoc_pid_t PID_current_d; //!< parameter determining the d current PID config
    sfoc_lpf_t LPF_current_q; //!<  parameter determining the current Low pass filter configuration
    sfoc_lpf_t LPF_current_d; //!<  parameter determining the current Low pass filter configuration
    sfoc_pid_t PID_velocity; //!< parameter determining the velocity PID configuration
    sfoc_pid_t P_angle;	//!< parameter determining the position PID configuration
    sfoc_lpf_t LPF_velocity; //!<  parameter determining the velocity Low pass filter configuration
    sfoc_lpf_t LPF_angle; //!<  parameter determining the angle low pass filter configuration
    unsigned int motion_downsample; //!< parameter defining the ratio of downsampling for move commad
    unsigned int motion_cnt; //!< counting variable for downsampling for move commad

    // sensor related variabels
    float sensor_offset; //!< user defined sensor zero offset
    float zero_electric_angle; //!< absolute zero electric angle - if available
    SFOC_DIRECTION sensor_direction; //!< default is CW. if sensor_direction == Direction::CCW then direction will be flipped compared to CW. Set to UNKNOWN to set by calibration
    bool pp_check_result; //!< the result of the PP check, if run during loopFOC

    /**
      * Sensor link:
      * - Encoder
      * - MagneticSensor*
      * - HallSensor
    */
    sfoc_sensor_t* sensor;
    /**
      * CurrentSense link
    */
    sfoc_current_sense_t* current_sense;
} sfoc_motor_t;

void sfoc_motor_init(sfoc_motor_t *motor);
void sfoc_motor_link_sensor(sfoc_motor_t *motor, sfoc_sensor_t* sensor);
void sfoc_motor_link_current_sense(sfoc_motor_t *motor, sfoc_current_sense_t* current_sense);

float sfoc_motor_shaft_angle(sfoc_motor_t *motor);
float sfoc_motor_shaft_velocity(sfoc_motor_t *motor);
float sfoc_motor_electrical_angle(sfoc_motor_t *motor);

#ifdef __cplusplus
}
#endif
#endif
