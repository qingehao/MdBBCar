#include "sfoc_sensor.h"
#include "sfoc_utils.h"
#include "sfoc_port.h"
#include <stddef.h>
#include "stdlib.h"

void sfoc_sensor_update(sfoc_sensor_t *sensor)
{
    float val = sensor->getSensorAngle(sensor->user_data);
    if (val<0) return;

    sensor->angle_prev_ts = sfoc_port_micros();
    float d_angle = val - sensor->angle_prev;

    // if overflow happened track it as full rotation
    if(abs(d_angle) > (0.8f*_2PI)) sensor->full_rotations += ( d_angle > 0 ) ? -1 : 1;
    sensor->angle_prev = val;
}

 /** get current angular velocity (rad/s) */
float sfoc_sensor_getVelocity(sfoc_sensor_t *sensor)
{
    // calculate sample time
    float Ts = (sensor->angle_prev_ts - sensor->vel_angle_prev_ts)*1e-6f;
    if (Ts < 0.0f) {    // handle micros() overflow - we need to reset vel_angle_prev_ts
        sensor->vel_angle_prev = sensor->angle_prev;
        sensor->vel_full_rotations = sensor->full_rotations;
        sensor->vel_angle_prev_ts = sensor->angle_prev_ts;
        return sensor->velocity;
    }
    if (Ts < sensor->min_elapsed_time) return sensor->velocity; // don't update velocity if deltaT is too small

    sensor->velocity = ( (float)(sensor->full_rotations - sensor->vel_full_rotations)*_2PI + (sensor->angle_prev - sensor->vel_angle_prev) ) / Ts;
    sensor->vel_angle_prev = sensor->angle_prev;
    sensor->vel_full_rotations = sensor->full_rotations;
    sensor->vel_angle_prev_ts = sensor->angle_prev_ts;
    return sensor->velocity;
}

int32_t sfoc_sensor_init(sfoc_sensor_t *sensor, sfoc_get_sensor_angle_t sensor_angle, void *user_data)
{
    if (sensor_angle == NULL) return  -1;

    sensor->user_data = user_data;
    sensor->getSensorAngle = sensor_angle;

    sensor->min_elapsed_time = 0.000100;
    // initialize all the internal variables of Sensor to ensure a "smooth" startup (without a 'jump' from zero)
    sensor->getSensorAngle(sensor->user_data); // call once
    sfoc_port_delayms(1);
    sensor->vel_angle_prev = sensor->getSensorAngle(sensor->user_data); // call again
    sensor->vel_angle_prev_ts = sfoc_port_micros();
    sfoc_port_delayms(1);
    sensor->getSensorAngle(sensor->user_data); // call once
    sfoc_port_delayms(1);
    sensor->angle_prev = sensor->getSensorAngle(sensor->user_data); // call again
    sensor->angle_prev_ts = sfoc_port_micros();

    return 0;
}

float sfoc_sensor_getMechanicalAngle(sfoc_sensor_t *sensor)
{
    return sensor->angle_prev;
}

float sfoc_sensor_getAngle(sfoc_sensor_t *sensor)
{
    return (float)sensor->full_rotations * _2PI + sensor->angle_prev;
}

double sfoc_sensor_getPreciseAngle(sfoc_sensor_t *sensor)
{
    return (double)sensor->full_rotations * (double)_2PI + (double)sensor->angle_prev;
}

int32_t sfoc_sensor_getFullRotations(sfoc_sensor_t *sensor)
{
    return sensor->full_rotations;
}

int sfoc_sensor_needsSearch(sfoc_sensor_t *sensor)
{
    return 0; // default false
}

void sfoc_sensor_set_min_elapsed_time(sfoc_sensor_t *sensor, float time)
{
    sensor->min_elapsed_time = time;
}

sfoc_sensor_t *sfoc_sensor_create(sfoc_get_sensor_angle_t sensor_angle, void *user_data)
{
    if (sensor_angle == NULL) return NULL;

    sfoc_sensor_t *sensor = sfoc_port_malloc(sizeof(sfoc_sensor_t));
    if (sensor != NULL)
    {
        sfoc_sensor_init(sensor, sensor_angle, user_data);
        return sensor;
    }
    return NULL;
}
