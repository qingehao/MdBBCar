#ifndef __SFOC_FOC_DRIVER_H__
#define __SFOC_FOC_DRIVER_H__

#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif
#include "stddef.h"
#include "stdbool.h"

typedef enum  {
  PHASE_OFF = 0, // both sides of the phase are off
  PHASE_ON = 1,  // both sides of the phase are driven with PWM, dead time is applied in 6-PWM mode
  PHASE_HI = 2,  // only the high side of the phase is driven with PWM (6-PWM mode only)
  PHASE_LO = 3,  // only the low side of the phase is driven with PWM (6-PWM mode only)
} SFOC_PHASE_STATE;


typedef enum
{
    SFOC_DRIVER_TYPE_UNKNOWN=0,
    SFOC_DRIVER_TYPE_BLDC,
    SFOC_DRIVER_TYPE_STEPPER,
} SFOC_DRIVER_TYPE;

typedef struct
{
    SFOC_DRIVER_TYPE driver_type;
    long  pwm_frequency; //!< pwm frequency value in hertz
    float voltage_power_supply; //!< power supply voltage
    float voltage_limit; //!< limiting voltage set to the motor

    bool initialized; //!< true if driver was successfully initialized
    void *params;    //!< pointer to hardware specific parameters of driver
    void *arg;
    bool enable_active_high; //!< enable pin should be set to high to enable the driver (default is HIGH)

    float dc_a; //!< currently set duty cycle on phaseA
    float dc_b; //!< currently set duty cycle on phaseB
    float dc_c; //!< currently set duty cycle on phaseC
    void (*set_pwm)(void *arg, float Ua, float Ub, float Uc);
    void (*set_phase_state)(void *arg, SFOC_PHASE_STATE sa, SFOC_PHASE_STATE sb, SFOC_PHASE_STATE sc);
    void (*enable)(void *arg);
    void (*disable)(void *arg);
} sfoc_driver_t;

#ifdef __cplusplus
}
#endif
#endif
