#ifndef __SFOC_CURRENT_SENSE_H__
#define __SFOC_CURRENT_SENSE_H__

#include "stdint.h"
#include "sfoc_utils.h"
#include "stdbool.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "sfoc_foc_driver.h"

// dq current structure
// dq voltage structs
typedef struct
{
    float d;
    float q;
} sfoc_dq_current_t, sfoc_dq_voltage_t;

// phase current structure
typedef struct
{
    float a;
    float b;
    float c;
} sfoc_phase_current_t;

// alpha beta current structure
typedef struct
{
    float alpha;
    float beta;
} sfoc_ab_current_t;

typedef void (*sfoc_get_phase_current_t)(float *a, float *b, float *c);

typedef struct
{
    sfoc_get_phase_current_t get_phase_current;
    void (*enable)();
    void (*disable)();
    sfoc_driver_t *driver;

    bool skip_align;  //!< variable signaling that the phase current direction should be verified during initFOC()
    bool initialized; // true if current sense was successfully initialized
} sfoc_current_sense_t;

float sfoc_get_dc_current(sfoc_current_sense_t *sense, float motor_electrical_angle);

void sfoc_get_foc_currents(sfoc_current_sense_t *sense, float angle_el, sfoc_dq_current_t *dq_current);

void sfoc_get_ab_current(sfoc_phase_current_t *phase_current, sfoc_ab_current_t *ab_current);

void sfoc_get_dq_currents(sfoc_ab_current_t *ab_current, float angle_el, sfoc_dq_current_t *dq_current);

void sfoc_read_average_currents(sfoc_current_sense_t *sense, int N, sfoc_phase_current_t *phase_c);

#ifdef __cplusplus
}
#endif
#endif
