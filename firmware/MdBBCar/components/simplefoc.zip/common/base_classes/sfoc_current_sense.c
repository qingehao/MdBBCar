#include "sfoc_current_sense.h"
#include "sfoc_utils.h"
#include "sfoc_port.h"

float sfoc_get_dc_current(sfoc_current_sense_t *sense, float motor_electrical_angle)
{
    sfoc_phase_current_t phase_current;
    sense->get_phase_current(&phase_current.a, &phase_current.b, &phase_current.c); // read current phase currents

    sfoc_ab_current_t ab_current;
    sfoc_get_ab_current(&phase_current, &ab_current); // calculate clarke transform

    // current sign - if motor angle not provided the magnitude is always positive
    float sign = 1;

    // if motor angle provided function returns signed value of the current
    // determine the sign of the current
    // sign(atan2(current.q, current.d)) is the same as c.q > 0 ? 1 : -1
    if(motor_electrical_angle) {
        float ct;
        float st;
        sfoc_port_sincos(motor_electrical_angle, &st, &ct);
        sign = (ab_current.beta*ct - ab_current.alpha*st) > 0 ? 1 : -1;
    }

    return sign * sfoc_port_sqrtApprox(ab_current.alpha*ab_current.alpha + ab_current.beta*ab_current.beta);
}

void sfoc_get_foc_currents(sfoc_current_sense_t *sense, float angle_el, sfoc_dq_current_t *dq_current)
{
    sfoc_phase_current_t phase_current;
    sense->get_phase_current(&phase_current.a, &phase_current.b, &phase_current.c); // read current phase currents

    sfoc_ab_current_t ab_current;
    sfoc_get_ab_current(&phase_current, &ab_current); // calculate clarke transform

    // calculate park transform
    sfoc_get_dq_currents(&ab_current, angle_el, dq_current);
}

void sfoc_get_ab_current(sfoc_phase_current_t *phase_current, sfoc_ab_current_t *ab_current)
{
    float i_alpha, i_beta;
    if (!phase_current->c) {
        // if only two measured currents
        i_alpha = phase_current->a;
        i_beta = _1_SQRT3 * phase_current->a + _2_SQRT3 * phase_current->b;
    } else if (!phase_current->a){
        // if only two measured currents
        float a = -phase_current->c - phase_current->b;
        i_alpha = a;
        i_beta = _1_SQRT3 * a + _2_SQRT3 * phase_current->b;
    } else if (!phase_current->b){
        // if only two measured currents
        float b = -phase_current->a - phase_current->c;
        i_alpha = phase_current->a;
        i_beta = _1_SQRT3 * phase_current->a + _2_SQRT3 * b;
    } else {
        // signal filtering using identity a + b + c = 0. Assumes measurement error is normally distributed.
        float mid = (1.f/3) * (phase_current->a + phase_current->b + phase_current->c);
        float a = phase_current->a - mid;
        float b = phase_current->b - mid;
        i_alpha = a;
        i_beta = _1_SQRT3 * a + _2_SQRT3 * b;
    }

    ab_current->alpha = i_alpha;
    ab_current->beta = i_beta;
}

// function used with the foc algorithm
//   calculating D and Q currents from Alpha Beta currents and electrical angle
//   - function calculating Clarke transform of the phase currents
void sfoc_get_dq_currents(sfoc_ab_current_t *ab_current, float angle_el, sfoc_dq_current_t *dq_current)
{
 // calculate park transform
    float ct;
    float st;
    sfoc_port_sincos(angle_el, &st, &ct);

    dq_current->d = ab_current->alpha * ct  + ab_current->beta * st;
    dq_current->q = ab_current->beta * ct  - ab_current->alpha * st;
}

void sfoc_read_average_currents(sfoc_current_sense_t *sense, int N, sfoc_phase_current_t *phase_c)
{
    sfoc_phase_current_t c0;
    sfoc_phase_current_t c1;

    sense->get_phase_current(&c0.a, &c0.b, &c0.c); // read current phase currents

    for (int i = 0; i < N; i++) {
        sense->get_phase_current(&c1.a, &c1.b, &c1.c); // read current phase currents

        c0.a = c0.a * 0.6f + 0.4f * c1.a;
        c0.b = c0.b * 0.6f + 0.4f * c1.b;
        c0.c = c0.c * 0.6f + 0.4f * c1.c;
        sfoc_port_delayms(3);
    }
    phase_c->a = c0.a;
    phase_c->b = c0.b;
    phase_c->c = c0.c;
};

#if 0
int sfoc_current_sense_driver_align(sfoc_current_sense_t *sense, float voltage, bool modulation_centered)
{
    int exit_flag = 1;
    if(sense->skip_align) return exit_flag;

    if (!sense->initialized) return 0;

    return alignBLDCDriver(sense, voltage, sense->driver, modulation_centered);
}


// Function aligning the current sense with motor driver
// if all pins are connected well none of this is really necessary! - can be avoided
// returns flag
// 0 - fail
// 1 - success and nothing changed
// 2 - success but pins reconfigured
// 3 - success but gains inverted
// 4 - success but pins reconfigured and gains inverted
int alignBLDCDriver(sfoc_current_sense_t *sense, float voltage, sfoc_driver_t* driver, bool modulation_centered)
{
    bool phases_switched = 0;
    bool phases_inverted = 0;
    float zero = 0;
    if(modulation_centered) zero = driver->voltage_limit/2.0;

    // set phase A active and phases B and C down
    // 300 ms of ramping
    for(int i=0; i < 100; i++){
        driver->set_pwm(voltage/100.0*((float)i)+zero , zero, zero);
        _delay(3);
    }
    _delay(500);
    sfoc_phase_current_t c_a;
    sfoc_read_average_currents(sense, 100, &c_a);

    driver->set_pwm(zero, zero, zero);
    // check if currents are to low (lower than 100mA)
    // TODO calculate the 100mA threshold from the ADC resolution
    // if yes throw an error and return 0
    // either the current sense is not connected or the current is
    // too low for calibration purposes (one should raise the motor.voltage_sensor_align)
    if ((fabs(c_a.a) < 0.1f) && (fabs(c_a.b) < 0.1f) && (fabs(c_a.c) < 0.1f))
    {
        SIMPLEFOC_DEBUG("CS: Err too low current, rise voltage!");
        return 0; // measurement current too low
    }

    // now we have to determine
    // 1) which pin correspond to which phase of the bldc driver
    // 2) if the currents measured have good polarity
    //
    // > when we apply a voltage to a phase A of the driver what we expect to measure is the current I on the phase A
    //   and -I/2 on the phase B and I/2 on the phase C

    // find the highest magnitude in c_a
    // and make sure it's around 2 (1.5 at least) times higher than the other two
    float ca[3] = {fabs(c_a.a), fabs(c_a.b), fabs(c_a.c)};
    uint8_t max_i = -1; // max index
    float max_c = 0; // max current
    float max_c_ratio = 0; // max current ratio
    for(int i = 0; i < 3; i++){
        if(!ca[i]) continue; // current not measured
        if(ca[i] > max_c){
            max_c = ca[i];
            max_i = i;
            for(int j = 0; j < 3; j++){
                if(i == j) continue;
                if(!ca[j]) continue; // current not measured
                float ratio = max_c / ca[j];
                if(ratio > max_c_ratio) max_c_ratio = ratio;
            }
        }
    }

    // check the current magnitude ratios
    // 1) if there is one current that is approximately 2 times higher than the other two
    //    this is the A current
    // 2) if the max current is not at least 1.5 times higher than the other two
    //    we have two cases:
    //    - either we only measure two currents and the third one is not measured - then phase A is not measured
    //    - or the current sense is not connected properly

    if(max_c_ratio >=1.5f){
        switch (max_i){
            case 1: // phase B is the max current
                SIMPLEFOC_DEBUG("CS: Switch A-B");
                // switch phase A and B
                _swap(pinA, pinB);
                _swap(offset_ia, offset_ib);
                _swap(gain_a, gain_b);
                _swap(c_a.b, c_a.b);
                phases_switched = true; // signal that pins have been switched
                break;
            case 2: // phase C is the max current
                SIMPLEFOC_DEBUG("CS: Switch A-C");
                // switch phase A and C
                _swap(pinA, pinC);
                _swap(offset_ia, offset_ic);
                _swap(gain_a, gain_c);
                _swap(c_a.a, c_a.c);
                phases_switched = true;// signal that pins have been switched
                break;
        }
        // check if the current is negative and invert the gain if so
        if( _sign(c_a.a) < 0 ){
            SIMPLEFOC_DEBUG("CS: Inv A");
            gain_a *= -1;
            phases_inverted = true; // signal that pins have been inverted
        }
    }else if(_isset(pinA) && _isset(pinB) && _isset(pinC)){
        // if all three currents are measured and none of them is significantly higher
        // we have a problem with the current sense
        SIMPLEFOC_DEBUG("CS: Err A - all currents same magnitude!");
        return 0;
    }else{ //phase A is not measured so put the _NC to the phase A
        if(_isset(pinA) && !_isset(pinB)){
            SIMPLEFOC_DEBUG("CS: Switch A-(B)NC");
            _swap(pinA, pinB);
            _swap(offset_ia, offset_ib);
            _swap(gain_a, gain_b);
            _swap(c_a.b, c_a.b);
            phases_switched = true; // signal that pins have been switched
        }else if(_isset(pinA) && !_isset(pinC)){
            SIMPLEFOC_DEBUG("CS: Switch A-(C)NC");
            _swap(pinA, pinC);
            _swap(offset_ia, offset_ic);
            _swap(gain_a, gain_c);
            _swap(c_a.b, c_a.c);
            phases_switched = true; // signal that pins have been switched
        }
    }
    // at this point the current sensing on phase A can be either:
    // - aligned with the driver phase A
    // - or the phase A is not measured and the _NC is connected to the phase A
    //
    // In either case A is done, now we have to check the phase B and C


    // set phase B active and phases A and C down
    // 300 ms of ramping
    for(int i=0; i < 100; i++){
        bldc_driver->setPwm(zero, voltage/100.0*((float)i)+zero, zero);
        _delay(3);
    }
    _delay(500);
    PhaseCurrent_s c_b = readAverageCurrents();
    bldc_driver->setPwm(zero, zero, zero);

    // check the phase B
    // find the highest magnitude in c_b
    // and make sure it's around 2 (1.5 at least) times higher than the other two
    float cb[3] = {fabs(c_b.a), fabs(c_b.b), fabs(c_b.c)};
    max_i = -1; // max index
    max_c = 0; // max current
    max_c_ratio = 0; // max current ratio
    for(int i = 0; i < 3; i++){
        if(!cb[i]) continue; // current not measured
        if(cb[i] > max_c){
            max_c = cb[i];
            max_i = i;
            for(int j = 0; j < 3; j++){
                if(i == j) continue;
                if(!cb[j]) continue; // current not measured
                float ratio = max_c / cb[j];
                if(ratio > max_c_ratio) max_c_ratio = ratio;
            }
        }
    }
    if(max_c_ratio >= 1.5f){
        switch (max_i){
            case 0: // phase A is the max current
                // this is an error as phase A is already aligned
                SIMPLEFOC_DEBUG("CS: Err align B");
                return 0;
            case 2: // phase C is the max current
                SIMPLEFOC_DEBUG("CS: Switch B-C");
                _swap(pinB, pinC);
                _swap(offset_ib, offset_ic);
                _swap(gain_b, gain_c);
                _swap(c_b.b, c_b.c);
                phases_switched = true; // signal that pins have been switched
                break;
        }
        // check if the current is negative and invert the gain if so
        if( _sign(c_b.b) < 0 ){
            SIMPLEFOC_DEBUG("CS: Inv B");
            gain_b *= -1;
            phases_inverted = true; // signal that pins have been inverted
        }
    }else if(_isset(pinB) && _isset(pinC)){
        // if all three currents are measured and none of them is significantly higher
        // we have a problem with the current sense
        SIMPLEFOC_DEBUG("CS: Err B - all currents same magnitude!");
        return 0;
    }else{ //phase B is not measured so put the _NC to the phase B
        if(_isset(pinB) && !_isset(pinC)){
            SIMPLEFOC_DEBUG("CS: Switch B-(C)NC");
            _swap(pinB, pinC);
            _swap(offset_ib, offset_ic);
            _swap(gain_b, gain_c);
            _swap(c_b.b, c_b.c);
            phases_switched = true; // signal that pins have been switched
        }
    }
    // at this point the current sensing on phase A and B can be either:
    // - aligned with the driver phase A and B
    // - or the phase A and B are not measured and the _NC is connected to the phase A and B
    //
    // In either case A and B is done, now we have to check the phase C
    // phase C is also aligned if it is measured (not _NC)
    // we have to check if the current is negative and invert the gain if so
    if(_isset(pinC)){
        if( _sign(c_b.c) > 0 ){ // the expected current is -I/2 (if the phase A and B are aligned and C has correct polarity)
            SIMPLEFOC_DEBUG("CS: Inv C");
            gain_c *= -1;
            phases_inverted = true; // signal that pins have been inverted
        }
    }

    // construct the return flag
    // if the phases have been switched return 2
    // if the gains have been inverted return 3
    // if both return 4
    uint8_t exit_flag = 1;
    if(phases_switched) exit_flag += 1;
    if(phases_inverted) exit_flag += 2;
    return exit_flag;
}
#endif
