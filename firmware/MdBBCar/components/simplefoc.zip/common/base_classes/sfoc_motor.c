#include "sfoc_motor.h"
#include "sfoc_defaults.h"
#include "stddef.h"
#include "sfoc_port.h"

void sfoc_motor_init(sfoc_motor_t *motor)
{
    // maximum angular velocity to be used for positioning
    motor->velocity_limit = DEF_VEL_LIM;
    // maximum voltage to be set to the motor
    motor->voltage_limit = DEF_POWER_SUPPLY;
    // not set on the begining
    motor->current_limit = DEF_CURRENT_LIM;

    // index search velocity
    motor->velocity_index_search = DEF_INDEX_SEARCH_TARGET_VELOCITY;
    // sensor and motor align voltage
    motor->voltage_sensor_align = DEF_VOLTAGE_SENSOR_ALIGN;

    // default modulation is SinePWM
    motor->foc_modulation = SpaceVectorPWM;

    // default target value
    motor->target = 0;
    motor->voltage.d = 0;
    motor->voltage.q = 0;
    // current target values
    motor->current_sp = 0;
    motor->current.q = 0;
    motor->current.d = 0;

    // voltage bemf
    motor->voltage_bemf = 0;

    // Initialize phase voltages U alpha and U beta used for inverse Park and Clarke transform
    motor->Ualpha = 0;
    motor->Ubeta = 0;

    //sensor
    motor->sensor_offset = 0.0f;
    motor->sensor = NULL;
    //current sensor
    motor->current_sense = NULL;

    sfoc_lpf_init(&motor->LPF_angle, 0.0f);
    sfoc_lpf_init(&motor->LPF_velocity, DEF_VEL_FILTER_Tf);
    sfoc_lpf_init(&motor->LPF_current_d, DEF_CURR_FILTER_Tf);
    sfoc_lpf_init(&motor->LPF_current_q, DEF_CURR_FILTER_Tf);

    sfoc_pid_init(&motor->PID_current_q, DEF_PID_CURR_P,DEF_PID_CURR_I,DEF_PID_CURR_D,DEF_PID_CURR_RAMP, DEF_POWER_SUPPLY);
    sfoc_pid_init(&motor->PID_current_d, DEF_PID_CURR_P,DEF_PID_CURR_I,DEF_PID_CURR_D,DEF_PID_CURR_RAMP, DEF_POWER_SUPPLY);
    sfoc_pid_init(&motor->PID_velocity, DEF_PID_VEL_P,DEF_PID_VEL_I,DEF_PID_VEL_D,DEF_PID_VEL_RAMP,DEF_PID_VEL_LIMIT);
    sfoc_pid_init(&motor->P_angle, DEF_P_ANGLE_P,0,0,0,DEF_VEL_LIM);
}

/**
	Sensor linking method
*/
void sfoc_motor_link_sensor(sfoc_motor_t *motor, sfoc_sensor_t* sensor)
{
    motor->sensor = sensor;
}

/**
	CurrentSense linking method
*/
void sfoc_motor_link_current_sense(sfoc_motor_t *motor, sfoc_current_sense_t* current_sense)
{
    motor->current_sense =  current_sense;
}

// shaft angle calculation
float sfoc_motor_shaft_angle(sfoc_motor_t *motor)
{
    // if no sensor linked return previous value ( for open loop )
    if (motor->sensor == NULL) return motor->shaft_angle;

    float angle = sfoc_sensor_getAngle(motor->sensor);
    return motor->sensor_direction * sfoc_lpf_operator(&motor->LPF_angle, angle)
            - motor->sensor_offset;
}

// shaft velocity calculation
float sfoc_motor_shaft_velocity(sfoc_motor_t *motor)
{
    // if no sensor linked return previous value ( for open loop )
    if(motor->sensor == NULL) return motor->shaft_velocity;

    float velocity = sfoc_sensor_getVelocity(motor->sensor);
    return motor->sensor_direction * sfoc_lpf_operator(&motor->LPF_velocity, velocity);
}

float sfoc_motor_electrical_angle(sfoc_motor_t *motor)
{
    // if no sensor linked return previous value ( for open loop )
    if (motor->sensor == NULL) return motor->electrical_angle;

    float mec_angle = sfoc_sensor_getMechanicalAngle(motor->sensor);

    return sfoc_port_normalize_angle( (float)(motor->sensor_direction * motor->pole_pairs) * mec_angle  - motor->zero_electric_angle );
}
