#include "sfoc_lpf.h"
#include "sfoc_port.h"

void sfoc_lpf_init(sfoc_lpf_t *lpf, float Tf)
{
    lpf->Tf = Tf;
    lpf->timestamp_prev = sfoc_port_micros();
    lpf->y_prev = 0.0f;
}

float sfoc_lpf_operator(sfoc_lpf_t *lpf, float x)
{
    unsigned long timestamp = sfoc_port_micros();
    float dt = (timestamp - lpf->timestamp_prev)*1e-6f;

    if (dt < 0.0f ) dt = 1e-3f;
    else if(dt > 0.3f) {
        lpf->y_prev = x;
        lpf->timestamp_prev = timestamp;
        return x;
    }

    float alpha = lpf->Tf/(lpf->Tf + dt);
    float y = alpha*lpf->y_prev + (1.0f - alpha)*x;
    lpf->y_prev = y;
    lpf->timestamp_prev = timestamp;
    return y;
}
