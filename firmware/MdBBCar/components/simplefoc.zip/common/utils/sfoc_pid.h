#ifndef __SFOC_PID_H__
#define __SFOC_PID_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    float P; //!< Proportional gain
    float I; //!< Integral gain
    float D; //!< Derivative gain
    float output_ramp; //!< Maximum speed of change of the output value
    float limit; //!< Maximum output value
    float error_prev; //!< last tracking error value
    float output_prev;  //!< last pid output value
    float integral_prev; //!< last integral component value
    unsigned long timestamp_prev; //!< Last execution timestamp
} sfoc_pid_t;

float sfoc_pid_init(sfoc_pid_t *pid, float P, float I, float D, float ramp, float limit);

float sfoc_pid_operator(sfoc_pid_t *pid, float error);

void sfoc_pid_reset(sfoc_pid_t *pid);

#ifdef __cplusplus
}
#endif
#endif
