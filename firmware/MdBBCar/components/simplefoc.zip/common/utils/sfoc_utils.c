#include "sfoc_utils.h"


// Electrical angle calculation
float sfoc_electricalAngle(float shaft_angle, int pole_pairs)
{
  return (shaft_angle * pole_pairs);
}