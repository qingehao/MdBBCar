#ifndef __SFOC_LPF_H__
#define __SFOC_LPF_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    float Tf; //!< Low pass filter time constant
    unsigned long timestamp_prev;  //!< Last execution timestamp
    float y_prev; //!< filtered value in previous execution step
} sfoc_lpf_t;

void sfoc_lpf_init(sfoc_lpf_t *lpf, float Tf);

float sfoc_lpf_operator(sfoc_lpf_t *lpf, float x);


#ifdef __cplusplus
}
#endif
#endif
